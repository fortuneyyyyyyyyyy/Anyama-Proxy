/**
 * Footer public : navigation utile, carte Abidjan et signature visuelle Kôkô Eats.
 */
import { lazy, Suspense, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowUpRight, Loader, Send } from 'lucide-react'
import KokoLogo from './KokoLogo'
import PwaInstallButton from './PwaInstallButton'
import { useGsapUnderline } from '../hooks/useGsapUnderline'
import { subscribeNewsletter } from '../api/index'
import '../styles/landing-minimal.css'

const FooterMap = lazy(() => import('./maps/MapboxMap').then(module => ({ default: module.MapboxMiniMap })))

const NAVIGATION = [
  {
    title: 'Explorer Kôkô Eats',
    links: [
      ['Restaurants à Abidjan', '/restaurants'],
      ['Carte interactive', '/map'],
      ['Cuisines ivoiriennes', '/cuisines/ivoirienne/'],
      ['Restaurants par quartier', '/quartiers/cocody/'],
    ],
  },
  {
    title: 'Informations',
    links: [
      ['À propos de Kôkô Eats', '/a-propos'],
      ['Aide et tarifs', '/aide#tarifs'],
      ['Devenir restaurant partenaire', '/register?role=restaurant'],
      ['Contact', '/contact'],
      ['Confidentialité', '/confidentialite'],
      ['Cookies', '/cookies'],
      ['Conditions générales', '/cgu'],
    ],
  },
]

export default function Footer({ workspace = false }) {
  const [email, setEmail] = useState('')
  const [state, setState] = useState('idle')
  const underlineRef = useRef(null)
  useGsapUnderline(underlineRef)

  const submit = async (event) => {
    event.preventDefault()
    if (!email || state === 'loading') return
    setState('loading')
    try {
      await subscribeNewsletter(email)
      setEmail('')
      setState('success')
    } catch {
      setState('error')
    }
  }

  const goToPageTop = () => window.scrollTo({ top: 0, left: 0, behavior: 'auto' })

  return (
    <footer ref={underlineRef} className={`koko-footer${workspace ? ' koko-footer--workspace' : ''}`}>
      <div className="koko-shell">
        <div className="koko-footer__grid">
          <div className="koko-footer__brand">
            <Link to="/" onClick={goToPageTop} aria-label="Kôkô Eats, accueil"><KokoLogo size={32} animated /></Link>
            <p className="koko-footer__brand-copy">La plateforme locale qui aide Abidjan à trouver ses cuisines, quartier par quartier.</p>
            {!workspace && <PwaInstallButton />}
            
          </div>

          {NAVIGATION.map((column) => (
            <div key={column.title}>
              <h3>{column.title}</h3>
              <nav className="koko-footer__links" aria-label={column.title}>
                {column.links.map(([label, to]) => <Link key={to} data-gsap-underline to={to} onClick={goToPageTop}>{label}<span className="koko-gsap-underline" aria-hidden="true" /></Link>)}
              </nav>
            </div>
          ))}

          {!workspace && (
              <div className="koko-footer__tools">
              <h3>Abidjan, sur la carte</h3>
              <div className="koko-footer__map">
                <Suspense fallback={<div style={{ height: 145, display: 'grid', placeItems: 'center', color: 'var(--text-muted)' }}>Chargement de la carte…</div>}>
                  <FooterMap center={[-3.9894, 5.3364]} zoom={12.6} height="145px" />
                </Suspense>
              </div>
              <form className="koko-footer__newsletter" onSubmit={submit}>
                <input type="email" value={email} onChange={(event) => { setEmail(event.target.value); setState('idle') }} placeholder="Recevoir les nouvelles locales" aria-label="Votre adresse email" required />
                <button type="submit" aria-label="S’inscrire à la newsletter">{state === 'loading' ? <Loader size={16} className="animate-spin" /> : <Send size={16} />}</button>
              </form>
              {state === 'success' && <p className="koko-footer__status koko-footer__status--success">Inscription confirmée.</p>}
              {state === 'error' && <p className="koko-footer__status koko-footer__status--error">Réessayez dans un instant.</p>}
            </div>
          )}
        </div>

        <div className="koko-footer__watermark" aria-hidden="true">
          <span className="koko-footer__watermark-koko">KÔKÔ</span><strong>EATS</strong>
        </div>

        <div className="koko-footer__bottom">
          <span>© 2026 — Kôkô Eats</span>
          <nav className="koko-footer__socials" aria-label="Réseaux sociaux">
            <a data-gsap-underline href="#" onClick={(event) => event.preventDefault()} aria-label="Instagram — bientôt disponible">Instagram<span className="koko-gsap-underline" aria-hidden="true" /></a>
            <a data-gsap-underline href="#" onClick={(event) => event.preventDefault()} aria-label="Facebook — bientôt disponible">Facebook<span className="koko-gsap-underline" aria-hidden="true" /></a>
            <a data-gsap-underline href="#" onClick={(event) => event.preventDefault()} aria-label="TikTok — bientôt disponible">TikTok<span className="koko-gsap-underline" aria-hidden="true" /></a>
          </nav>
          <a data-gsap-underline className="koko-footer__studio-link" href="https://akatech.vercel.app/" target="_blank" rel="noreferrer" aria-label="Visiter AKATech Studio">
            <span>AKATech Studio</span><span className="koko-gsap-underline" aria-hidden="true" />
            <span className="koko-footer__studio-reveal" aria-hidden="true"><img src="/images/brand/akatech-studio-hover.webp" alt="" loading="lazy" /></span>
          </a>
        </div>
      </div>
    </footer>
  )
}
